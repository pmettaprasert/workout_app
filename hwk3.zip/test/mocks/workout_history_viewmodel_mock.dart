import 'package:mockito/mockito.dart';
import 'package:mockito/annotations.dart';
import 'package:hwk3/viewmodels/workout_history_viewmodel.dart';


@GenerateMocks([WorkoutHistoryViewModel])
void main() {}