import 'package:mockito/annotations.dart';
import 'package:hwk3/viewmodels/performance_viewmodel.dart';

@GenerateMocks([PerformanceViewModel])
void main() {}