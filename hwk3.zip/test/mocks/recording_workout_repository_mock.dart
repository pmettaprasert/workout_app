import 'package:mockito/annotations.dart';
import 'package:hwk3/repository/recording_workout_repository.dart';

@GenerateMocks([RecordingWorkoutRepository])
void main() {}