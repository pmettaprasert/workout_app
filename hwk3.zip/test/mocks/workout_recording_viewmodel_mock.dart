import 'package:mockito/mockito.dart';
import 'package:mockito/annotations.dart';
import 'package:hwk3/viewmodels/workout_recording_viewmodel.dart';


@GenerateMocks([WorkoutRecordingViewModel])
void main() {}