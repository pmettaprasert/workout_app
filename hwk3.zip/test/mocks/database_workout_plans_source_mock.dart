import 'package:mockito/annotations.dart';
import 'package:hwk3/data/local_database/database_workout_plans_source.dart';

@GenerateMocks([DatabaseWorkoutPlansDataSource])
void main() {}