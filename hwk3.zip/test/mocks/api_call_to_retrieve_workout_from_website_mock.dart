import 'package:mockito/annotations.dart';
import 'package:hwk3/service/api_calls/api_call_to_retrieve_workout_from_website.dart';


@GenerateMocks([ApiCallToRetrieveWorkoutFromWebsite])
void main() {}